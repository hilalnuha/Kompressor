/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Vector;

/**
 *
 * @author USER
 */
public class Tester_1 {

    public static void main(String[] args) {
       
readFileHDeCompress(2, null);
    }

    public static void readFileHDeCompress(int k, String namafile) {
        byte data;
        int fileSize = 0;
        byte[] bval = new byte[100];
        String fileName = "test.txt";
        String fileNameD = "test-d.txt";
        String compressedName = "compressed.huf";
        String encoded = "";
        int numSym = k;//1;
        FileInputStream fin = null;
        FileOutputStream fo = null;
        File fil = null;
        BufferedWriter writer = null;
        String simbol = "";

        Vector<Byte> fileR = new Vector<Byte>();

        try {

            File file = new File(fileName);

            byte[] decom = new byte[(int) file.length()];
            //byte[] decom=new byte[filRs];
            int totalBytesRead = 0;
            BufferedInputStream input = new BufferedInputStream(new FileInputStream(compressedName));
            while (totalBytesRead < decom.length) {
                int bytesRemaining = decom.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = input.read(decom, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }

            for (byte b : fileR) {
                //        decom[fileR.indexOf(b)]=b;
            }
            
            //System.arraycopy(fileR, 0, decom, 0, filRs);
            String decomFileStr = CLKompressor.toBinary(decom);
            System.out.println(decomFileStr);
byte[] bait = new BigInteger(decomFileStr, 2).toByteArray();
decomFileStr = CLKompressor.toBinary(bait);
System.out.println(decomFileStr);

        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found");
        } catch (IOException e) {
            System.out.println("Terjadi Exception");
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                    System.out.println("Terjadi Exception");
                }
            }
        }



    }
}
