/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor;

import java.math.BigInteger;

/**
 *
 * @author USER
 */
public class Tester {
public static void main(String[] args){
    String tes="000000000000000";
    System.out.println(tes+" "+tes.length());
    int padding = 8 - (tes.length() % 8);
    for (int p=0;p<padding;p++){
        tes="1"+tes;
    }
    //tes="1"+tes;
    System.out.println(tes);
//byte[] bait=CLKompressor.toBytefromBinary(tes);
    byte[] bait=new BigInteger(tes, 2).toByteArray();
int arr = bait.length;
            byte[] byteWrite = new byte[arr + 1];
            byteWrite[0] = Byte.valueOf(padding + "");
            //for (int x=0;x<bval.length;x++){
            //  byteWrite[x+1]=bval[x]; 
            System.arraycopy(bait, 0, byteWrite, 1, bait.length);
String prod=CLKompressor.toBinaryPrinter(byteWrite);
System.out.println(prod);
String prod2=CLKompressor.toBinary(bait);
System.out.println(prod2);

}    
}
