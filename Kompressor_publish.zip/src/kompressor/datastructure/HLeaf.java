/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor.datastructure;

import java.util.Comparator;

/**
 *
 * @author USER
 */
public class HLeaf implements Comparable<HLeaf>, Comparator<HLeaf> {
    public int bitValue;
    public String prefix;
    public HLeaf parent;
    public HLeaf[] sons;
    int freq;
    float prob;
    
    public HLeaf(){
    bitValue=0;
    prefix="";
    sons=new HLeaf[2];
    freq=0;
    
    }
    public HLeaf(int f){
        this();
        freq=f;
        
    }

        @Override
    public int compareTo(HLeaf o) {
      return (this.prefix).compareTo(o.prefix);    }

    @Override
    public int compare(HLeaf o1, HLeaf o2) {
      return o1.freq - o2.freq;    }

    public void parenting(HLeaf l0,HLeaf l1){
    l0.parent=this;
    l1.parent=this;
    
    this.sons[0]=l0;
    this.sons[1]=l1;
    
    l0.bitValue=0;
    l1.bitValue=1;
    
    freq=l0.freq+l1.freq;
    }
}
