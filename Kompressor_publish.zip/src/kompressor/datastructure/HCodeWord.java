/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor.datastructure;

import java.util.Comparator;

/**
 *
 * @author USER
 */
public class HCodeWord implements Comparable<HCodeWord>, Comparator<HCodeWord> {
    public String symbol,codeword;;
    public float prob;
    public int freq;
    public HCodeWord(){}
    
    public HCodeWord(String s,String c,float p,int f){
        symbol=s;
        codeword=c;
        prob=p;
        freq=f;
    }

    @Override
    public int compareTo(HCodeWord o) {
      return (this.symbol).compareTo(o.symbol);    }

    @Override
    public int compare(HCodeWord o1, HCodeWord o2) {
      return o1.freq - o2.freq;    }
    
   
    
}
