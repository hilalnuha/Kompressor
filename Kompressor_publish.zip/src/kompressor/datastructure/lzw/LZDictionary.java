/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor.datastructure.lzw;

import java.math.BigInteger;
import java.util.Vector;
import kompressor.datastructure.HDictionary;

/**
 *
 * @author USER
 */
public class LZDictionary {

    int k;
    public Vector<LZCodeword> table;
    String tempSymbol = "";
    public HDictionary hdi;
    public int bitIndex;

    public LZDictionary() {
        table = new Vector<LZCodeword>();
        hdi = new HDictionary();
    }

    public void buildTable(String binString, int k) {
        this.k = k;
        String simbol = "";
        bitIndex = 1;
        for (int n = 0; n < binString.length(); n++) {
            simbol = simbol + binString.charAt(n);
            //System.out.print(binString.charAt(n));
            if (simbol.length() >= k) {
                addSymbol(simbol);
                hdi.addVocab(simbol);
                simbol = "";
            }
            if ((n == (binString.length()) && (!simbol.equals("")))) {
                addSymbol(simbol);
                hdi.addVocab(simbol);
            }
        }
        constructIndexBinary();
        constructIndexPrefixBinary();
        constructCodes();
        //  for (LZCodeword lz:table){
        //
        //       if (lz.symbol.equals(tempSymbol)){
        //        }
        //        }

    }

    private void addSymbol(String sym) {
        boolean symExist = false;
        tempSymbol = tempSymbol + sym;
        for (LZCodeword lz : table) {

            if (lz.symbol.equals(tempSymbol)) {
                symExist = true;
                break;
            }

        }

        if (!symExist) {
            LZCodeword lz = new LZCodeword();
            int tempSameLength = 0;
            int tempLength = 0;
            for (LZCodeword lzt : table) {
                tempLength = maxPrefixLength(lzt.symbol, tempSymbol);
               // System.out.println(" tempsame "+ tempSameLength +" templeng"+ tempLength);
                if (tempSameLength < tempLength) {
                    lz.indRef = lzt.index;
                    tempSameLength = tempLength;
                }
            }
            lz.symbol = tempSymbol;
            lz.index = table.size() + 1;
            lz.indexBinStr = Integer.toBinaryString(lz.index);//.substring(31-bitIndex);
            if (lz.indexBinStr.length() > bitIndex) {
                bitIndex = lz.indexBinStr.length();
            }

            table.add(lz);
            tempSymbol = "";
        }
    }

    private void constructIndexBinary() {
        for (LZCodeword lz : table) {
            for (int i = lz.indexBinStr.length(); i < bitIndex; i++) {
                lz.indexBinStr = "0" + lz.indexBinStr;
            }
            
        }
    }
    private void constructIndexPrefixBinary() {
        for (LZCodeword lz : table) {
            lz.posNumPrefix = Integer.toBinaryString(lz.indRef);
            for (int i = lz.posNumPrefix.length(); i < bitIndex; i++) {
                lz.posNumPrefix = "0" + lz.posNumPrefix;
            }
            
        }
        
    }
       private void constructCodes() {
        for (LZCodeword lz : table) {
            lz.codeword=lz.posNumPrefix +lz.symbol.charAt(lz.symbol.length()-1);
                    }
        }
    
    public void printTable() {
        for (LZCodeword lz : table) {
            System.out.println(lz.index + ". Symbol " + lz.symbol + ", address: " + lz.indexBinStr+ ", ref: " + lz.posNumPrefix+ ", CW: " + lz.codeword);
        }
    }

    public static int maxPrefixLength(String s1, String s2) {
        int max = 0;
        int compLength = (s1.length() > s2.length()) ? s2.length() : s1.length();
        //System.out.println(s1+" compare "+ s2+" compare length "+compLength);
        for (int i = 0; i < compLength; i++) {
            if (s1.charAt(i) != s2.charAt(i)) {
                //System.out.println(s1.charAt(i)+" not Equal "+ s2.charAt(i));
                break;
            }
            max++;
        }
        //System.out.println(" max "+ max);
        return max;
    }
    public String getCompressedString(String source){
    String s="";
        for (LZCodeword lz : table) {
            s=s+lz.codeword;
        }
         
        if (source.length()!=minSymbol().length()){
        s=s+getCodes(source.substring(minSymbol().length()));
        //System.out.println("compresssed +"+getCodes(source.substring(minSymbol().length())));
        //System.out.println(source);
       // System.out.println(minSymbol());
        }
    
    return s;
    }
    public byte[] getCompressedBinaryForFile(String source){
        byte[] bval;
        String encoded=getCompressedString(source);
      //  System.out.println(encoded.length()/8+" bytes,"+encoded.length()%8+" bits");
        int padding = 8 - (encoded.length() % 8);
            for (int p = 0; p < padding; p++) {
                encoded = "1" + encoded;
                //System.out.println("padded");
            }
            //System.out.println("padded "+encoded.length()/8+" bytes,"+encoded.length()%8+" bits");
            //bval = toBytefromBinary(encoded);
            bval = new BigInteger(encoded, 2).toByteArray();
            int arr = bval.length;
            byte[] byteWrite = new byte[arr + 1];
            byteWrite[0] = Byte.valueOf(padding + "");
            //for (int x=0;x<bval.length;x++){
            //  byteWrite[x+1]=bval[x]; 
            System.arraycopy(bval, 0, byteWrite, 1, bval.length);
            //System.out.println(byteWrite.length+" bytes");
        return byteWrite;
    }
    private String minSymbol(){
        String s="";
        for (LZCodeword lz : table){
        s=s+lz.symbol;
        }
        return s;
    }
    public String getSymbol(String code){
        String s="";
        for (LZCodeword lz : table) {
           // System.out.println(code+"=?"+lz.codeword);
            if (code.equals(lz.codeword)){
            s=lz.symbol;
            //System.out.println(lz.symbol);
            }
        }
    return s;
    }
    public String getCodes(String sym){
        String s="";
        for (LZCodeword lz : table) {
            if (sym.equals(lz.symbol)){
            s=lz.codeword;
            
            }
        }
    return s;
    }
    public String getSourceFromCodes(String source){
        String s="";
        int symbolNum=source.length()/(bitIndex+1);
        if ((source.length()%(bitIndex+1))>0){
            System.out.println(" sisa "+(source.length()%(bitIndex+1)));
        }
        for (int i=0;i<symbolNum;i++){
        s=s+getSymbol(source.substring(i*(bitIndex+1), ((i+1)*(bitIndex+1))));
        }
        return s;
    }
}
