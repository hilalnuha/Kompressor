/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor.datastructure.lzw;

/**
 *
 * @author USER
 */
public class LZCodeword {
    public String symbol,indexBinStr,prefix,posNumPrefix,codeword;
    public int index,indRef;
    public LZCodeword(){
        symbol="";
        indexBinStr="";
        prefix="";
        posNumPrefix="";
        codeword="";
        index=1;
        indRef=0;
}
    
}
