/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package kompressor.datastructure;

import java.util.Collections;
import java.util.Vector;

/**
 *
 * @author USER
 */
public class HDictionary {

    public Vector<HCodeWord> cws;
    Vector<String> symbols;
    Vector<HLeaf> leaves;
    Vector<Vector<HLeaf>> tree;
    public int totalFreq = 0;

    public HDictionary() {
        cws = new Vector<HCodeWord>();
        symbols = new Vector<String>();
        leaves = new Vector<HLeaf>();
        tree = new Vector<Vector<HLeaf>>();
    }

    public void addVocab(String s) {
        totalFreq++;
        if (!symbols.contains(s)) {
            symbols.add(s);
            cws.add(new HCodeWord(s, "", 0f, 1));
        } else {
            int index = 0;
            index = symbols.indexOf(s);
            for (String str : symbols) {
            }
            cws.get(index).freq++;
        }
    }
public String getCodeWord(String s) {
    String cword="";
        for (HCodeWord cw : cws) {
            if (cw.symbol.equals(s)){
            cword=cw.codeword;
            }
        }
        return cword;
    }
public String getSymbol(String code) {
    String symbol="";
        for (HCodeWord cw : cws) {
            if (cw.codeword.equals(code)){
            symbol=cw.symbol;
            }
        }
        return symbol;
    }

    public void printCodeWord() {
        System.out.println();
        System.out.println(" printing codewords..." );
        Collections.sort(cws, new HCodeWord());
        for (HCodeWord cw : cws) {
            System.out.println(cw.symbol + " codeword: "+cw.codeword+" freq " + cw.freq);
        }
        System.out.println("total freq :" + totalFreq);
    }

    public void printTree() {

        for (HLeaf cw : tree.get(0)) {
            System.out.println("leaf cw " + cw.bitValue + " freq " + cw.freq);
        }
        System.out.println("total freq :" + totalFreq);
    }

    public void constructTree() {
        for (HCodeWord cw : cws) {
            cw.prob=((float)cw.freq/(float)totalFreq);
        }
        
        Collections.sort(cws, new HCodeWord());
        for (HCodeWord cw : cws) {
            leaves.add(new HLeaf(cw.freq));
        }
        tree.add(leaves);
        int depth = 0;
        while ((tree.get(depth).get(0).freq != totalFreq)) {

            HLeaf parent = new HLeaf();
            parent.parenting(tree.get(depth).get(0), tree.get(depth).get(1));

            Vector<HLeaf> newDepth = (Vector<HLeaf>) tree.get(depth).clone();
            if (newDepth.size() == 1) {
                System.out.println("newDepth size " + newDepth.size());
            }
            newDepth.remove(tree.get(depth).get(0));
            newDepth.remove(tree.get(depth).get(1));

            newDepth.add(parent);
            Collections.sort(newDepth, new HLeaf());

            tree.add(newDepth);
            depth++;
            System.out.println("f: " + parent.freq + "  total " + this.totalFreq + " leaf: " + newDepth.size() + " src tot " + cws.size());
            System.out.println("f top tree: " + tree.get(depth).get(0).freq);
            System.out.println("dept: " + depth);
            if (tree.get(depth).get(0).freq == totalFreq) {
                System.out.println("reach the top ");
            }

        }
        //construcCodewordFromTree
        for (HLeaf leaf:tree.get(0)){
            HLeaf dummy=leaf;
            leaf.prefix=leaf.bitValue+"";
            while(dummy.parent!=null){
                leaf.prefix=dummy.parent.bitValue+leaf.prefix;
                dummy=dummy.parent;
            }
            leaf.prefix=leaf.prefix.substring(1);
            System.out.println("leaf cw "+leaf.prefix+" freq "+leaf.freq);  
          
        }
        
        //map sourse to tree
        for (HLeaf leaf:tree.get(0)){
            
            cws.get(tree.get(0).indexOf(leaf)).codeword=leaf.prefix;
            
            
          
        }
        
    }
}
