/*
 * Hilal H. Nuha
 * text writer http://stackoverflow.com/questions/15754523/how-to-write-text-file-java
 * writing binary credits http://www.javapractices.com/topic/TopicAction.do?Id=245
 * byte array conversion credits http://stackoverflow.com/questions/11528898/convert-byte-to-binary-in-java
 */
package kompressor;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import kompressor.datastructure.HCodeWord;
import kompressor.datastructure.HDictionary;
import kompressor.datastructure.lzw.LZCodeword;
import kompressor.datastructure.lzw.LZDictionary;

/**
 *
 * @author USER
 */
public class CLKompressor {

    public static void main(String[] args) {
        String command = "";
        String[] commArg;//=new String[3];
        byte[] comB = new byte[100];
        Scanner scan = new Scanner(System.in);
        System.out.println("Hilal Hudan Nuha 201309210");
        System.out.println();
        System.out.println("Koppression: Huffman and Lempel-Ziv file compressor");
        System.out.println();

        do {
            System.out.println("Choose menu..k=number of symbol per codeword");
            System.out.println("1. Compress and DeCompress Huffman.. enter :h k <filename.txt>");
            //System.out.println("2.  Huffman.. enter :dh k <filename.huf>");
            //System.out.println("3. Compress Lempel-Ziv.. enter :lz k <filename.huf>");
            System.out.println("2. Compress and DeCompress Lempel-Ziv.. enter :dlz k <filename.huf>");
            System.out.println("3. exit.. enter :e");
            //System.in.read(comB);
            command = scan.nextLine();//(new String(comB));
            System.out.println("you choose " + command);

            if (command.split(" ").length == 3) {
                commArg = command.split(" ").clone();
                int k = Integer.parseInt(commArg[1]);//k value                    
                System.out.println(commArg[1]);
                if (commArg[0].equals("h")) {
                    //mulai huffman compress
                  //  readFileHCompress(k, commArg[2]);
                    readFileHDeCompress(k, commArg[2]);
                } else if (commArg[0].equals("dh")) {
                    //mulai huffman decompress    
                    readFileHDeCompress(k, commArg[2]);
                } else if (commArg[0].equals("lz")) {
                    //mulai lempel-ziv compress
                    readFileLZDeCompress(k, commArg[2]);
                } else if (commArg[0].equals("dlz")) {
                    //mulai lempel-ziv decompress
                    readFileLZDeCompress(k, commArg[2]);
                }

            }

        } while (!command.equals("e"));
        System.out.println("thank you..");
    }

    public static HDictionary readFileHCompress(int k, String namafile) {
        byte data;
        int fileSize = 0;
        byte[] bval = new byte[100];
        String fileName = "test.txt";
        String compressedName = "compressed.huf";

        String encoded = "";
        int numSym = k;//1;
        FileInputStream fin = null;
        FileOutputStream fo = null;
        String simbol = "";
        HDictionary di = new HDictionary();

        try {
            fin = new FileInputStream(fileName);
            data = (byte) fin.read();

            while (data != -1) {
                fileSize++;
                //System.out.print((char) data);
                simbol = simbol + ((char) data);
                if (simbol.length() == k) {
                    //System.out.println(simbol);
                    di.addVocab(simbol);
                    simbol = "";
                }
                data = (byte) fin.read();
                if (data == -1) {
                    //System.out.println(simbol);
                    //last symbol
                    di.addVocab(simbol);
                }
            }
            fin.close();
            di.constructTree();
            //di.printTree();
            di.printCodeWord();

            fin = new FileInputStream(fileName);

            data = (byte) fin.read();

            while (data != -1) {
                //System.out.print((char) data);
                simbol = simbol + ((char) data);
                if (simbol.length() == k) {
                    //System.out.println(simbol);
                    encoded = encoded + di.getCodeWord(simbol);
                    simbol = "";
                }
                data = (byte) fin.read();
                if (data == -1) {
                    //System.out.println(simbol);
                    //last symbol
                    encoded = encoded + di.getCodeWord(simbol);
                }
            }
            fin.close();

            int padding = 8 - (encoded.length() % 8);
            for (int p = 0; p < padding; p++) {
                encoded = "1" + encoded;
            }
            //bval = toBytefromBinary(encoded);//
            bval = new BigInteger(encoded, 2).toByteArray();
            //bval=toBytefromBinary(encoded);
            int arr = bval.length;
            byte[] byteWrite = new byte[arr + 1];
            byteWrite[0] = Byte.valueOf(padding + "");
            //for (int x=0;x<bval.length;x++){
            //  byteWrite[x+1]=bval[x]; 
            System.arraycopy(bval, 0, byteWrite, 1, bval.length);
            //  }



            fo = new FileOutputStream(compressedName);
            fo.write(byteWrite);
            fo.close();
            //.substring(Integer.SIZE - Byte.SIZE);
            System.out.println("reverse is  : ");
            //System.out.println(toBinary(bval));
            System.out.println(toBinaryPrinter(byteWrite));
            System.out.println("Original file Size=" + fileSize + " bytes");
            System.out.println("Compression Rate=" + (((float) byteWrite.length / (float) fileSize) * 100) + " %");
            System.out.println("is it equal to   ");
            System.out.println(encoded.substring(padding));
            System.out.println("size: " + encoded.length() + " bit=" + (encoded.length() / 8) + " byte " + (encoded.length() % 8) + " bit");

            System.out.println("size after enc: " + bval.length + " bytes");

        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found");
        } catch (IOException e) {
            System.out.println("Terjadi Exception");
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                    System.out.println("Terjadi Exception");
                }
            }
        }
        return di;
    }

    public static HDictionary readFileHDeCompress(int k, String namafile) {
        byte data;
        int fileSize = 0;
        byte[] bval = new byte[100];
        
        String fileName = "test.txt";
        if(!namafile.equals("")){
            fileName=namafile;
        }
      //  String fileNameD = "test-d.txt";
      //  String compressedName = "compressed.huf";
        String encoded = "";
        int numSym = k;//1;
        FileInputStream fin = null;
        FileOutputStream fo = null;
        File fil = null;
        BufferedWriter writer = null;
        String simbol = "";
        HDictionary di = new HDictionary();
        //Vector<Byte> fileR = new Vector<Byte>();

        try {
            fin = new FileInputStream(fileName);
            data = (byte) fin.read();

            while (data != -1) {
                fileSize++;
                //System.out.print((char) data);
                simbol = simbol + ((char) data);
                if (simbol.length() == k) {
                    //System.out.println(simbol);
                    di.addVocab(simbol);
                    simbol = "";
                }
                data = (byte) fin.read();
                if (data == -1) {
                    //System.out.println(simbol);
                    //last symbol
                    di.addVocab(simbol);
                }
            }
            fin.close();
            di.constructTree();
            //di.printTree();
            di.printCodeWord();

            fin = new FileInputStream(fileName);

            data = (byte) fin.read();

            while (data != -1) {
                //System.out.print((char) data);
                simbol = simbol + ((char) data);
                if (simbol.length() == k) {
                    //System.out.println(simbol);
                    encoded = encoded + di.getCodeWord(simbol);
                    simbol = "";
                }
                data = (byte) fin.read();
                if (data == -1) {
                    //System.out.println(simbol);
                    //last symbol
                    encoded = encoded + di.getCodeWord(simbol);
                }
            }
            fin.close();

            int padding = 8 - (encoded.length() % 8);
            for (int p = 0; p < padding; p++) {
                encoded = "1" + encoded;
            }
            //bval = toBytefromBinary(encoded);
            bval = new BigInteger(encoded, 2).toByteArray();
            int arr = bval.length;
            byte[] byteWrite = new byte[arr + 1];
            byteWrite[0] = Byte.valueOf(padding + "");
            //for (int x=0;x<bval.length;x++){
            //  byteWrite[x+1]=bval[x]; 
            System.arraycopy(bval, 0, byteWrite, 1, bval.length);
            //  }
            fo = new FileOutputStream(fileName+"-"+k+".huf");
            fo.write(byteWrite);
            fo.close();
            //.substring(Integer.SIZE - Byte.SIZE);
            System.out.println("reverse is  : ");
            //System.out.println(toBinary(bval));
            System.out.println(toBinaryPrinter(byteWrite));
            System.out.println("Original file Size=" + fileSize + " bytes");
            System.out.println("Compression Rate=" + (((float) byteWrite.length / (float) fileSize) * 100) + " %");
            System.out.println("is it equal to   ");

            //begin decompress
            //   fin = new FileInputStream(compressedName);

            //   data = (byte) fin.read();

            //    while (data != -1) {
            //System.out.print((char) data);
            //      fileR.add(data);
            //      data = (byte) fin.read();

            //  }

            // fin.close();
            //    int filRs = fileR.size();
            //for (byte b : fileR) {
            //        decom[fileR.indexOf(b)]=b;
            //   }
            //System.arraycopy(fileR, 0, decom, 0, filRs);
            File file = new File(fileName+"-"+k+".huf");

            byte[] decom = new byte[(int) file.length()];
            System.out.println("decom file size:" + decom.length);
            //byte[] decom=new byte[filRs];
            int totalBytesRead = 0;
            BufferedInputStream input = new BufferedInputStream(new FileInputStream(fileName+"-"+k+".huf"));
            while (totalBytesRead < decom.length) {
                int bytesRemaining = decom.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = input.read(decom, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }


            String decomFileStr = toBinaryPrinter(decom);
            System.out.println("decom file code: ");
            System.out.println(decomFileStr);

            //checking
            System.out.println("encoded source:");
            System.out.println(encoded.substring(padding));
            System.out.println("size: " + encoded.length() + " bit=" + (encoded.length() / 8) + " byte " + (encoded.length() % 8) + " bit");
            System.out.println("size after enc: " + bval.length + " bytes");

            //decode to symbol
            System.out.println("decoded source:");
            String codes = "";
            String decodes = "";
            String sym = "";
            for (int i = 0; i < decomFileStr.length(); i++) {
                codes = codes + decomFileStr.charAt(i);
                //System.out.println(codes);
                sym = di.getSymbol(codes);
                if (!sym.equals("")) {
                    System.out.print(sym);
                    decodes = decodes + sym;
                    codes = "";
                }
            }
            System.out.println();
            System.out.println("size " + decodes.length() + " bytes");
            fo = new FileOutputStream("decom-" + fileName +"-"+k+".txt");
            fo.write(decodes.getBytes());
            fo.close();

            //write codes to file
            fil = new File("codes-" + fileName +"-"+k+".cdw");
            writer = new BufferedWriter(new FileWriter(fil));
            writer.write("codewords and compression summary\n");
            writer.write("Compression Ratio=" + (((float) byteWrite.length / (float) fileSize) * 100) + " %\n");
            writer.write("k=" + k + " generate " + di.cws.size() + " symbols,  Original filesize=" + fileSize + " bytes, " + "Compressed filesize=" + byteWrite.length + " bytes, \n");
            float avgLength = 0f;
            float entropy = 0f;
            for (HCodeWord cw : di.cws) {
                writer.write(cw.symbol + " codeword: " + cw.codeword + " prob " + cw.prob * 100 + "% freq " + cw.freq + "\n");
                avgLength = avgLength + (cw.codeword.length() * cw.prob);
                entropy = entropy + -(cw.prob * ((float) (Math.log(cw.prob) / Math.log(2))));
            }
            writer.write("rate=" + avgLength / k + " ,entropy=" + entropy + " ,efficiency=" + entropy / avgLength + " \n");
            writer.flush();
        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found");
        } catch (IOException e) {
            System.out.println("Terjadi Exception");
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                    System.out.println("Terjadi Exception");
                }
            }
        }


        return di;
    }

    public static void readFileLZDeCompress(int k, String namafile) {
        byte data;
        int fileSize = 0;
        byte[] bval = new byte[100];
        String fileName = "test2.txt";
        if(!namafile.equals("")){
            fileName=namafile;
        }
       // String fileNameD = "test-d.txt";
      //  String compressedName = "compressed.lzw";
      //  String encoded = "";
        int numSym = k;//1;
        FileInputStream fin = null;
        FileOutputStream fo = null;
        File fil = null;
        BufferedWriter writer = null;
        String simbol = "";

        Vector<Byte> fileR = new Vector<Byte>();
        LZDictionary lzdi=new LZDictionary();

        try {

            File file = new File(fileName);

            byte[] decom = new byte[(int) file.length()];
            //byte[] decom=new byte[filRs];
            int totalBytesRead = 0;
            BufferedInputStream input = new BufferedInputStream(new FileInputStream(fileName));
            while (totalBytesRead < decom.length) {
                int bytesRemaining = decom.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = input.read(decom, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }

            for (byte b : fileR) {
                //        decom[fileR.indexOf(b)]=b;
            }
            

            //System.arraycopy(fileR, 0, decom, 0, filRs);
            String decomFileStr = CLKompressor.toBinary(decom);
            String source=decomFileStr;
            System.out.println(decomFileStr);
            byte[] bait = new BigInteger(decomFileStr, 2).toByteArray();
            
            decomFileStr = CLKompressor.toBinary(bait);
            System.out.println(decomFileStr);
            lzdi.buildTable(decomFileStr, k);
            //lzdi.printTable();
            System.out.println("BinaryEncoded length "+lzdi.getCompressedString(source).length()+", "+lzdi.bitIndex+" bit, symbol num: "+lzdi.table.size());
            System.out.println(lzdi.getCompressedString(source));
            System.out.println(toBinaryPrinter(lzdi.getCompressedBinaryForFile(source)));

            byte[] byteWrite=lzdi.getCompressedBinaryForFile(source);
            fo = new FileOutputStream(fileName+"-"+k+".lzw");
            fo.write(byteWrite);
            fo.close();
            
            file=new File(fileName+"-"+k+".lzw");
            
            decom = new byte[(int) file.length()];
            System.out.println("file length "+file.length());
            System.out.println("decom file size:" + decom.length);
            //byte[] decom=new byte[filRs];
            totalBytesRead = 0;
            input = new BufferedInputStream(new FileInputStream(fileName+"-"+k+".lzw"));
            while (totalBytesRead < decom.length) {
                int bytesRemaining = decom.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = input.read(decom, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }


            decomFileStr = toBinaryPrinter(decom);
            System.out.println("decom file code: ");
            System.out.println(decomFileStr);
            String decomStr=lzdi.getSourceFromCodes(decomFileStr);
            System.out.println(decomStr);
            bait = new BigInteger(decomStr, 2).toByteArray();
            
            for (int i=0;i<bait.length;i++){
            System.out.print((char)bait[i]);
            }
            System.out.println();
            fo = new FileOutputStream("decom-" + fileName+"-"+k+".lzw" + ".txt");
            fo.write(bait);
            fo.close();
            
            fil = new File("codes-" + fileName +"-"+k+".clz");
            fileSize=bait.length;
            writer = new BufferedWriter(new FileWriter(fil));
            writer.write("codewords and compression summary\n");
            writer.write("Compression Ratio=" + (((float) byteWrite.length / (float) fileSize) * 100) + " %\n");
            writer.write("index length="+lzdi.bitIndex+"bit, k=" + k + " generate " + lzdi.table.size() + " symbols,  Original filesize=" + fileSize + " bytes, " + "Compressed filesize=" + byteWrite.length + " bytes, \n");
            float avgLength = 0f;
            float entropy = 0f;
            float prob=1f/(float)lzdi.table.size();
            for (LZCodeword lz : lzdi.table) {
                //cw.prob=((float)cw.freq)/((float)lzdi.hdi.totalFreq);
                writer.write(lz.index + ". Symbol " + lz.symbol + ", address: " + lz.indexBinStr+ ", index ref: " + lz.indRef+", bin ref: " + lz.posNumPrefix+ ", CW: " + lz.codeword+ "\n");
                //avgLength = avgLength + (cw.codeword.length() * cw.prob);
                
                entropy = entropy + -( prob* ((float) (Math.log(prob) / Math.log(2))));
            }
            
            for (HCodeWord cw : lzdi.hdi.cws) {
                cw.prob=((float)cw.freq)/((float)lzdi.hdi.totalFreq);
              //  writer.write(cw.symbol + " " + cw.codeword + " prob " + cw.prob * 100 + "% freq " + cw.freq + "\n");
                avgLength = avgLength + (cw.codeword.length() * cw.prob);
                //entropy = entropy + -(cw.prob * ((float) (Math.log(cw.prob) / Math.log(2))));
            }
            writer.write("rate=" + (lzdi.bitIndex+1) / k + " ,entropy=" + entropy + " ,efficiency=" + entropy / (lzdi.bitIndex+1) + " \n");
            writer.flush();
        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found");
        } catch (IOException e) {
            System.out.println("Terjadi Exception");
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                    System.out.println("Terjadi Exception");
                }
            }
        }



    }

    static String toBinary(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * Byte.SIZE);
        for (int i = 0; i < Byte.SIZE * bytes.length; i++) {
            sb.append((bytes[i / Byte.SIZE] << i % Byte.SIZE & 0x80) == 0 ? '0' : '1');
        }
        return sb.toString();
    }

    static String toBinaryPrinter(byte[] bytes1) {
        int cut = bytes1[0];
        if (cut == 8) {
            //     cut=0;
        }

        byte[] bytes = new byte[bytes1.length - 1];
       // System.out.println("cut "+ cut+", length "+bytes.length);
        System.arraycopy(bytes1, 1, bytes, 0, bytes1.length - 1);

        StringBuilder sb = new StringBuilder(bytes.length * Byte.SIZE);
        for (int i = 0; i < Byte.SIZE * bytes.length; i++) {
            char br = ((bytes[i / Byte.SIZE] << i % Byte.SIZE & 0x80) == 0 ? '0' : '1');
            sb.append(br);
        }
        String hasil=sb.toString();
        int i=0;
        while(hasil.charAt(i)=='0'){
        //    System.out.println(hasil.charAt(i)+" "+i);
            i++;
       }
        hasil=hasil.substring(i);
         //System.out.println(i);
        return hasil.substring(cut);
        //return sb.toString();
    }

    static byte[] toBytefromBinary(String s) {
        int sLen = s.length();
        byte[] toReturn = new byte[(sLen + Byte.SIZE - 1) / Byte.SIZE];
        char c;
        for (int i = 0; i < sLen; i++) {
            if ((c = s.charAt(i)) == '1') {
                toReturn[i / Byte.SIZE] = (byte) (toReturn[i / Byte.SIZE] | (0x80 >>> (i % Byte.SIZE)));
            } else if (c != '0') {
                throw new IllegalArgumentException();
            }
        }
        return toReturn;
    }
}
